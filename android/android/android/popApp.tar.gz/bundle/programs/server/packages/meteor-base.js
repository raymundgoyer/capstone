(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteor-base'] = {};

})();

//# sourceMappingURL=meteor-base.js.map
